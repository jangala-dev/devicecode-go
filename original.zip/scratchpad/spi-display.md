Below is a concrete way to add an SPI-driven display under the model we’ve agreed (transactional vs stream buses, non-blocking HAL loop, uniform capabilities, bounded queues).

# 1) Extend the bus model to include SPI (transactional)

Add SPI to your board descriptor and platform provider. SPI belongs to **BusTransactional**.

```go
// internal/platform/boards/descriptor.go
type SPIDesc struct {
    ID        string // "spi0","spi1"
    SCK, MOSI int
    MISO      int // optional for write-only displays; set to -1 if unused
    Hz        uint32
}
type Descriptor struct {
    // ...
    SPI  []SPIDesc
}
```

Platform provider (RP2) configures only declared buses and registers owners:

```go
// internal/platform/platform_rp2.go (sketch)
for _, d := range boards.Selected.SPI {
    spi := pickSPIPeripheral(d.ID) // machine.SPI0 or SPI1
    _ = spi.Configure(machine.SPIConfig{
        Frequency: choose(d.Hz, 24_000_000), // default 24 MHz
        SCK: machine.Pin(d.SCK), SDO: machine.Pin(d.MOSI),
        SDI: func() machine.Pin { if d.MISO>=0 { return machine.Pin(d.MISO) }; return machine.NoPin }(),
        Mode: 0, // set by device later if needed
    })
    reg.RegisterTxn(core.BusID(d.ID), newSPIOwner(spi)) // TxnOwner
}
```

A generic transactional owner already exists (same type as for I2C), backed by a single goroutine with a bounded queue. It executes closures that do the actual SPI I/O.

# 2) Device: display over SPI (example: ST77xx-class)

Treat the display as a **Device** that consumes:

* one **TxnOwner** for the SPI bus; and
* a small set of **GPIO pins**: `CS`, `DC` (data/command), `RST`, `BL` (backlight PWM or GPIO).

It exposes one capability: `display/N`.

## Capability definition

* **Info** (retained): width, height, colour format (`rgb565`), rotation.
* **State** (retained): link (`up|down|degraded`), last update TS, optional error.
* **Event** (non-retained): optional `presented` notifications.

## Control verbs (uniform surface)

* `display/fill` → `{colour_565:uint16}`
* `display/blit` → `{x:int,y:int,w:int,h:int, pixels_b64:string}`  (RGB565 bytes)
* `display/set_backlight` → `{percent:uint8}` (0–100)
* `display/sleep` / `display/wake`

All controls are **non-blocking**: the device **queues** a transactional closure onto the SPI owner via a bounded queue; the control reply is `{accepted:true}` or `{ok:false,error:"busy"}`.

## Device builder (sketch)

```go
// devices/display/spi_display.go
type Params struct {
    CS, DC, RST, BL int   // GPIO numbers
    Width, Height   int
    Hz              uint32 // optional SPI freq override
}

type Display struct {
    id      string
    spi     core.TxnOwner      // transactional bus owner
    port    SPI                // underlying SPI handle if you expose one
    cs, dc  core.GPIOPin
    rst     core.GPIOPin
    bl      core.GPIOPin
    w, h    int
    // pre-encoded command buffers, line staging buffer, etc.
}

type builder struct{}

func (builder) Build(ctx context.Context, in core.BuilderInput) (core.Device, error) {
    if in.BusRef.Class != core.BusTransactional { return nil, errWrongClass }
    txn, ok := in.Buses.Txn(in.BusRef.ID)
    if !ok { return nil, errUnknownBus }

    var p Params; _ = util.DecodeJSON(in.Params, &p)

    // Pins
    cs, _ := in.GPIO.ByNumber(p.CS)
    dc, _ := in.GPIO.ByNumber(p.DC)
    rst, _ := in.GPIO.ByNumber(p.RST)
    bl, _ := in.GPIO.ByNumber(p.BL)
    _ = cs.ConfigureOutput(true) // deassert CS (high)
    _ = dc.ConfigureOutput(true)
    _ = rst.ConfigureOutput(true)
    _ = bl.ConfigureOutput(true) // backlight on by default

    d := &Display{
        id: in.ID, spi: txn, cs: cs, dc: dc, rst: rst, bl: bl,
        w: p.Width, h: p.Height,
    }
    return d, nil
}
```

> Note: The SPI “driver” handle itself can be hidden inside the `TxnOwner`. Your closures will capture whatever wrapper you provide in the platform layer. If you prefer, expose a small `SPI` interface alongside `TxnOwner` so closures can call `spi.Tx(w,r)`.

## Device init

Perform the reset and panel init over SPI **inside the transactional owner** (closure), so the main loop never blocks.

```go
func (d *Display) Init(ctx context.Context) error {
    // Hard reset
    d.rst.Set(false); time.Sleep(10 * time.Millisecond); d.rst.Set(true); time.Sleep(120 * time.Millisecond)

    // Panel init sequence (example)
    return d.spi.Do(func() error {
        d.cs.Set(false)                 // select
        defer d.cs.Set(true)
        d.cmd(0x01)                     // SWRESET
        delayMs(150)
        d.cmd(0x11)                     // SLPOUT
        delayMs(120)
        d.cmd(0x3A); d.data8(0x55)      // COLMOD=16-bit
        d.cmd(0x29)                     // DISPON
        return nil
    })
}
```

Helper methods (toggling DC and sending bytes) use the SPI wrapper available in scope of the closure. Keep them tiny and zero-alloc.

## Controls

### Fill

```go
func (d *Display) Control(kind core.Kind, method string, payload any) (any, error) {
    if kind != core.CapDisplay { return nil, core.ErrUnsupported }
    switch method {
    case "fill":
        p := payload.(types.DisplayFill)
        ok := d.tryQueue(func() error {
            d.window(0,0,d.w-1,d.h-1)
            d.cmd(0x2C) // RAMWR
            // Stream colour in chunks
            const chunk = 4096
            buf := make([]byte, chunk)
            for i := 0; i < chunk; i += 2 {
                buf[i] = byte(p.Colour >> 8); buf[i+1] = byte(p.Colour)
            }
            px := d.w * d.h * 2
            for px > 0 {
                n := chunk; if n > px { n = px }
                d.data(buf[:n])
                px -= n
            }
            return nil
        })
        if !ok { return types.Ack{OK:false, Error:"busy"}, nil }
        return types.Ack{OK:true}, nil
```

### Blit (rectangular upload)

```go
    case "blit":
        p := payload.(types.DisplayBlit) // contains x,y,w,h and pixels []byte (RGB565)
        if !boundsOK(d.w, d.h, p) { return types.Ack{OK:false, Error:"bad_rect"}, nil }
        ok := d.tryQueue(func() error {
            d.window(p.X, p.Y, p.X+p.W-1, p.Y+p.H-1)
            d.cmd(0x2C)
            // Chunk large buffers to bound call time
            const max = 4096
            for off := 0; off < len(p.Pixels); off += max {
                end := off + max; if end > len(p.Pixels) { end = len(p.Pixels) }
                d.data(p.Pixels[off:end])
            }
            return nil
        })
        if !ok { return types.Ack{OK:false, Error:"busy"}, nil }
        return types.Ack{OK:true}, nil
```

### Backlight / power

```go
    case "set_backlight":
        p := payload.(types.DisplayBacklight)
        lvl := p.Percent >= 50 // simple GPIO on/off; PWM later
        d.bl.Set(lvl)
        return types.Ack{OK:true}, nil

    case "sleep":
        _ = d.spi.TryQueue(func() error { d.cmd(0x10); return nil })
        return types.Ack{OK:true}, nil
    case "wake":
        _ = d.spi.TryQueue(func() error { d.cmd(0x11); return nil })
        return types.Ack{OK:true}, nil
    default:
        return nil, core.ErrUnsupported
    }
}
```

> **Non-blocking:** controls use `TryQueue` (see below) to post work to the SPI owner. Replies are immediate. If the queue is saturated, return `busy`.

## Posting work non-blockingly

Extend `TxnOwner` with a non-blocking enqueue for long operations:

```go
// core/bus.go
type TxnOwner interface {
    Do(fn TxnFn) error            // synchronous (used at Init and read paths)
    TryQueue(fn TxnFn) bool       // fire-and-forget; false if queue full
}
```

Owner implementation:

```go
func (o *txnOwner) TryQueue(fn core.TxnFn) bool {
    select { case o.q <- fn: return true; default: return false }
}
```

The owner goroutine executes closures sequentially; large blits are broken into chunks inside the closure to keep ISR latency acceptable on the MCU.

# 3) HAL integration (unchanged pattern)

* Capability registered as `display/N` with retained `info` (`width`, `height`, `fmt:"rgb565"`) and `state`.
* HAL never calls SPI directly. It only routes control messages to the device, which posts closures to the owner.
* If you need a “heartbeat”, you can omit it for displays; state transitions occur on first successful command or first error.

# 4) Shared SPI with other devices

Because SPI is a transactional bus, the **SPI owner serialises** all users (the display and any other SPI devices). To avoid monopolising the bus:

* **Chunk long transfers** (as shown).
* Keep the owner queue capacity modest (e.g. 8–16).
* Prefer `TryQueue` + `busy` over back-pressuring the HAL loop.

If fairness becomes a concern, you can split a full-frame blit into **scanline closures** (one closure per line). That lets other devices interleave their transactions between lines.

# 5) Testing (host)

* Host platform registers a fake SPI as a transactional owner. Its `exec(fn)` records command/data sequences and simulates timing.
* Unit tests feed `display/blit` with small buffers and assert that:

  * the owner queue accepts or rejects under pressure as expected;
  * commands and data are emitted in the correct order (e.g. `CASET`, `RASET`, `RAMWR` then pixel stream);
  * bounds checks reject out-of-range rectangles.

# 6) Summary of moving parts

* **Board**: add an `SPIDesc` for the wired bus and `GPIOName`s for CS/DC/RST/BL if you prefer naming.
* **Platform**: build one **TxnOwner** per SPI port, configured from the board descriptor.
* **Device**: implement `display` over SPI using `TxnOwner.(Do|TryQueue)`, GPIO pins for control lines, chunked writes, and non-blocking controls.
* **HAL**: unchanged non-blocking loop; uniform capability topics and control verbs.

This keeps the UART/I2C/SPI story consistent: SPI uses the same **transactional owner** pattern as I2C, while the display’s large writes remain non-blocking thanks to `TryQueue` and chunking.
