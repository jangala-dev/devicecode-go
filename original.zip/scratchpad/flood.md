Short answer: you’re servicing the **Charge Status** edges correctly (you re-arm to “next edges” after each batch), but you’re **not doing the equivalent for the LTC4015’s Charger State faults** (e.g. `BatMissingFault`). As a result the fault latch remains asserted, ALERT# stays low, your worker keeps looping, and you emit `bat_missing` over and over.

There are three parts to fix or confirm.

---

## 1) Clear and re-arm **Charger State** alerts on every service

In `configureDevice()` you do:

```go
_ = drv.EnableChargerStateAlertsMask(ltc4015.BatMissingFault | ltc4015.BatShortFault | ltc4015.MaxChargeTimeFault)
_ = drv.ClearChargerStateAlerts()
```

…but in `translateAlerts()` you never:

* clear the **charger state** latches after handling them, nor
* re-arm the **charger state** alert mask to only fire on the *next* edges (you only do that for **charge status**).

Add logic mirroring your `ChgStatus` block. For example:

```go
// Device fields (add):
// lastChgState atomic.Uint32

func (d *Device) translateAlerts(ev ltc4015.AlertEvent) {
    now := time.Now().UnixNano()

    // --- Charger state faults / events ---
    if ev.ChgState != 0 {
        // Optional: report only on transitions using a simple edge detector.
        prev := ltc4015.ChargerState(d.lastChgState.Load())
        curr := ev.ChgState
        changed := prev ^ curr

        if curr.Has(ltc4015.BatMissingFault) && changed.Has(ltc4015.BatMissingFault) {
            _ = d.res.Pub.Emit(core.Event{Addr: d.aChg, IsEvent: true, EventTag: "bat_missing", TS: now})
        }
        if curr.Has(ltc4015.BatShortFault) && changed.Has(ltc4015.BatShortFault) {
            _ = d.res.Pub.Emit(core.Event{Addr: d.aChg, IsEvent: true, EventTag: "bat_short", TS: now})
        }
        if curr.Has(ltc4015.MaxChargeTimeFault) && changed.Has(ltc4015.MaxChargeTimeFault) {
            _ = d.res.Pub.Emit(core.Event{Addr: d.aChg, IsEvent: true, EventTag: "max_charge_time_fault", TS: now})
        }

        d.lastChgState.Store(uint32(curr))

        // Re-arm: enable only edges that are NOT currently asserted.
        en := ltc4015.BatMissingFault | ltc4015.BatShortFault | ltc4015.MaxChargeTimeFault
        if cs, err := d.dev.ChargerState(); err == nil {
            en &^= cs
            if err := d.dev.EnableChargerStateAlertsMask(en); err != nil {
                d.evtErrChg("enable_chg_state_alerts_failed", string(errcode.MapDriverErr(err)))
            }
            if err := d.dev.ClearChargerStateAlerts(); err != nil {
                d.evtErrChg("clear_chg_state_alerts_failed", string(errcode.MapDriverErr(err)))
            }
        } else {
            d.evtErrChg("read_charger_state_failed", string(errcode.MapDriverErr(err)))
        }
    }

    // ... existing VIN / BSR and Charge Status handling ...
}
```

This ensures:

* you only emit `bat_missing` **on transition** to the asserted condition; and
* the mask is set to fire again only when the bit clears and later asserts (i.e. a genuine edge).

If you don’t want the “transition-only” behaviour, you can keep the existing single-shot event emission but you must still re-arm and clear the latches as above; otherwise, the ALERT# line will remain asserted and you’ll busy-loop.

---

## 2) Backoff if ALERT# is held low by a latched fault

Your `serviceSMBAlertWhileLow()` already caps the fast loop with `maxIters` and uses a retry timer (2 ms). If the fault is expected to persist (e.g. no battery connected), consider a gentler retry (e.g. 20–100 ms) once you’ve re-armed masks and cleared latches, to avoid hammering the bus while the line is level-asserted by other devices on the SMBus.

---

## 3) Operational checks

* If a battery is **not fitted by design**, you may want to **omit `BatMissingFault` from the enabled mask** at configuration time, or treat it as a one-time informational event.
* If a battery **is** fitted, repeated `bat_missing` can also indicate wiring/shunt sense issues or chemistry configuration. Your code already clears and configures; ensure `RSNSB_uOhm` and cell count are correct, and that SMBALERT# has a pull-up (you set GPIO pull-up in the builder; that is correct).

---

### Why the flood happens

* `ServiceSMBAlert()` yields `ev.ChgState` with `BatMissingFault` set.
* Your code emits `bat_missing` but **doesn’t clear the Charger State latch** and **doesn’t re-arm to opposite edges**.
* ALERT# remains asserted; your worker immediately services again and repeats the emission.

Implementing the re-arm + clear sequence (and, optionally, transition filtering) will stop the repeated `bat_missing` spam.
