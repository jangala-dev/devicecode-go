Below are minimal changes that prepend each human-readable log line with an elapsed time in seconds (to hundredths). The timestamp is emitted once at the start of each line, regardless of whether you build the line with `Print`, `Deci`, `Hundredths`, or `Println`.

## 1) Logger: add timestamp prefixing

```go
// at top of the file (same package), extend Logger
type Logger struct {
	uart1     *shmring.Ring
	t0        time.Time
	lineStart bool
}

// set a start time (call this once early in main)
func (l *Logger) SetStart(t time.Time) { l.t0 = t }

// internal: emit prefix if we are at the start of a new line
func (l *Logger) writePrefixIfLineStart() {
	if !l.lineStart {
		return
	}
	if l.t0.IsZero() {
		l.t0 = time.Now()
	}
	el := time.Since(l.t0)

	secs := int(el / time.Second)
	hund := int((el % time.Second) / (10 * time.Millisecond)) // 0..99

	// Write: 123.45␠
	// (no allocations; reuse existing helpers)
	l.writeString(strconvx.Itoa(secs))
	l.writeString(".")
	if hund < 10 {
		l.writeString("0")
	}
	l.writeString(strconvx.Itoa(hund))
	l.writeString(" ")
	l.lineStart = false
}
```

Modify the existing methods to hook the prefixer:

```go
// ensure the first write in a line gets the prefix
func (l *Logger) writeString(s string) {
	l.writePrefixIfLineStart()
	if s != "" {
		print(s)
	}
	if l.uart1 != nil && s != "" {
		_ = l.uart1.TryWriteFrom([]byte(s))
	}
}

func (l *Logger) writeBytes(b []byte) {
	if len(b) == 0 {
		return
	}
	l.writePrefixIfLineStart()
	print(string(b))
	if l.uart1 != nil {
		_ = l.uart1.TryWriteFrom(b)
	}
}

func (l *Logger) newline() {
	print("\r\n")
	if l.uart1 != nil {
		_ = l.uart1.TryWriteFrom(nl[:])
	}
	l.lineStart = true
}
```

Initialise the logger so that the very first log line gets a prefix:

```go
var log = Logger{lineStart: true}
```

`Print`, `Println`, `Deci`, and `Hundredths` do not need further changes, because the first write of each line now triggers the prefix automatically.

If you prefer to avoid the early `Print` in `Deci`, you can optionally collapse it to a single `Println`, but this is not required with the `lineStart` gate above.

## 2) main.go: set the start time once

Call this before the first `log.Println`:

```go
func main() {
	time.Sleep(3 * time.Second)
	log.SetStart(time.Now()) // anchor t0 for timestamps

	ctx := context.Background()
	// …
```

## Result

Each log line is prefixed with elapsed seconds to hundredths since `SetStart`, e.g.:

```
0.00 [main] bootstrapping bus …
0.02 [main] starting hal.Run …
3.41 [value] env/temperature/core °C= 24.3
5.00 [mem]  alloc: 123456  heapSys: 262144  mallocs: 789  frees: 456
```

This approach is self-contained, avoids allocations, and works across all existing logging call sites without further modification.
