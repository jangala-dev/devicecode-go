You can rationalise “buses” into two classes with a single registry and uniform ownership rules. This prepares you for I2C, SPI, 1-Wire, GPIO bit-banged links, UART, CAN, USB CDC, etc., while keeping the HAL loop non-blocking.

# Bus classes

1. **Transactional buses** – request/response transactions that must be serialised on a shared link.
   Examples: I2C, SPI, 1-Wire.
   Semantics: “run this closure atomically on the bus and give me success/failure.”

2. **Stream buses** – full/half-duplex byte or frame streams with independent RX and TX.
   Examples: UART, CAN, USB CDC ACM, BLE UART.
   Semantics: “enqueue TX frames; RX arrives as events.”

Both classes use one **owner** per physical port, created at boot from the board descriptor. Owners are the only code that calls the underlying driver, so the HAL main loop never blocks.

# Core, stable interfaces

```go
// internal/core/bus.go
package core

import "context"

// Classification
type BusClass uint8
const (
    BusTransactional BusClass = iota
    BusStream
)

// Common registry key
type BusID string // e.g. "i2c0", "spi1", "uart0", "can0"

// ---- Transactional bus owner (I2C, SPI, 1-Wire) ----
type TxnFn func() error
type TxnOwner interface {
    Do(fn TxnFn) error                      // serialised; owner goroutine executes fn
    Stats() TxnStats                        // optional: drops, queue depth, etc.
}
type TxnStats struct{ QLen, QCap, Drops uint32 }

// ---- Stream bus owner (UART, CAN, CDC) ----
type StreamOwner interface {
    TrySend(p []byte) bool                  // enqueue non-blocking; false if full
    Events() <-chan StreamEvent             // RX (and optional TX echoes), bounded
    Stats() StreamStats
}
type StreamEvent struct {
    DevID string     // logical device bound to this port
    Data  []byte
    TSms  int64
    // Optional metadata: direction (rx/tx), frame flags, etc.
}
type StreamStats struct{ RxDrops, TxDrops, RxQLen, TxQLen uint32 }

// ---- Bus registry used by device builders ----
type BusRegistry interface {
    ClassOf(id BusID) (BusClass, bool)
    Txn(id BusID) (TxnOwner, bool)         // valid when class == BusTransactional
    Stream(id BusID) (StreamOwner, bool)   // valid when class == BusStream
}
```

You expose only this from the HAL core. Platform code wraps `machine` (RP2) or host fakes to implement these owners.

# Platform/board to owners

* Board descriptor selects which ports exist and their pins.
* Platform provider builds the appropriate **owner** per port:

  * **Transactional**: one goroutine per port with a bounded request queue (`Do(fn)`).
  * **Stream**: **two goroutines per port**: RX reader and TX owner, each with bounded queues, as previously discussed.
* Provider registers each owner in a `BusRegistry` implementation.

```go
// internal/platform/registry.go
type busRegistry struct {
    classes map[BusID]BusClass
    txn  map[BusID]TxnOwner
    strm map[BusID]StreamOwner
}
func (r *busRegistry) ClassOf(id BusID) (BusClass, bool) { c, ok := r.classes[id]; return c, ok }
func (r *busRegistry) Txn(id BusID) (TxnOwner, bool)     { o, ok := r.txn[id]; return o, ok }
func (r *busRegistry) Stream(id BusID) (StreamOwner, bool){ o, ok := r.strm[id]; return o, ok }
```

# Devices bind to a class, not an implementation

A device declares the bus **class** it needs and the `BusID`. The builder then asks the registry for the corresponding owner. This removes shape-specific knowledge from devices.

```go
// internal/core/device.go (extensions)
type BusRef struct{ Class BusClass; ID BusID }

type BuilderInput struct {
    ID, Type string
    Params   any
    BusRef   BusRef
    Buses    BusRegistry
    GPIO     PinFactory
    IRQ      IRQRegistrar
}
```

# Using the model in device builders

## I2C sensor (transactional)

```go
// devices/aht20/builder.go
func (b builder) Build(ctx context.Context, in core.BuilderInput) (core.Device, error) {
    if in.BusRef.Class != core.BusTransactional { return nil, errWrongClass }
    txn, ok := in.Buses.Txn(in.BusRef.ID)
    if !ok { return nil, errUnknownBus }
    d := &AHT20{
        id: in.ID,
        bus: txn,                    // keep the TxnOwner
        // driver init uses txn.Do(...)
    }
    return d, nil
}

// devices/aht20/device.go (synchronous Read)
func (d *AHT20) Read(ctx context.Context, emit func(core.Value)) error {
    if err := d.bus.Do(func() error { return d.dev.Trigger() }); err != nil { return err }
    var s sample
    if err := d.bus.Do(func() error { return d.dev.Collect(&s) }); err != nil { return err }
    now := nowMs()
    emit(core.Value{Kind: core.CapTemp,  Payload: TempValue{DeciC: s.DeciC, TS: now}})
    emit(core.Value{Kind: core.CapHum,   Payload: HumValue{DeciPct: s.DeciRH, TS: now}})
    return nil
}
```

## UART serial (stream)

```go
// devices/serial/builder.go
func (b builder) Build(ctx context.Context, in core.BuilderInput) (core.Device, error) {
    if in.BusRef.Class != core.BusStream { return nil, errWrongClass }
    st, ok := in.Buses.Stream(in.BusRef.ID)
    if !ok { return nil, errUnknownBus }
    // Register with IRQ/event intake if you need HAL to route RX to capability:
    // Alternatively, consume st.Events() directly from HAL via dev ID.
    return &Serial{ id: in.ID, bus: st }, nil
}

// devices/serial/device.go
type Serial struct{ id string; bus core.StreamOwner }

func (s *Serial) Control(kind core.Kind, method string, payload any) (any, error) {
    if kind != core.CapSerial || method != "write" { return nil, ErrUnsupported }
    data := payload.(UARTWrite).Data
    if ok := s.bus.TrySend(data); !ok {
        return WriteReply{OK: false, Queued: false}, nil
    }
    return WriteReply{OK: true, Queued: true}, nil
}
```

HAL listens once to each stream owner’s `Events()` and publishes RX as `capability/serial/<id>/event`. Because the event contains `DevID`, the main loop can route it to the correct capability without involving the device.

# Control plane remains uniform

* `read_now`: for **any** capability that has a TTL cache or can provide an on-demand reading, HAL calls `dev.Read` (which in turn uses `TxnOwner.Do` or returns immediately if it is event-only).
* Kind-specific verbs are forwarded to `Device.Control`. Devices use their bus owner shape without leaking it to HAL.

# Non-blocking guarantees and back-pressure

* **HAL loop** never calls driver methods; it enqueues:

  * Transactional: post `TxnFn` to the owner’s queue (owner goroutine executes it).
  * Stream TX: `TrySend` to the owner’s bounded `txQ`.
* **RX** arrives via owners as events into bounded channels. Drop on pressure with counters in `StreamStats`.
* **Queue defaults** (tune per MCU):

  * Transactional owner: 16 entries.
  * Stream TX queue: 32 entries; RX slab pool: 32–64 slabs of 128 bytes.
* **Fast failure**: if a queue is full, return `{ok:false, error:"busy"}` in the control reply.

# Adding future buses

* **SPI**: implement a `TxnOwner` with chip-select selection embedded in the closure or as part of device state.
* **1-Wire**: `TxnOwner` (timed transaction closures).
* **CAN**: `StreamOwner` with fixed-size frames and ID metadata in `StreamEvent`.
* **USB CDC**: `StreamOwner` identical to UART.

No device or HAL changes are required beyond adding the platform provider for the new bus and listing it in the board descriptor.

# Minimal code sketches for owners

## Transactional owner (generic)

```go
type txnOwner struct {
    q chan core.TxnFn
    done chan error
    exec func(fn core.TxnFn) error // calls the driver (I2C Tx, SPI Xfer, etc.)
}

func newTxnOwner(exec func(core.TxnFn) error) *txnOwner {
    return &txnOwner{ q: make(chan core.TxnFn, 16), done: make(chan error, 1), exec: exec }
}
func (o *txnOwner) Run(ctx context.Context) {
    for {
        select {
        case <-ctx.Done(): return
        case fn := <-o.q:
            o.done <- o.exec(fn) // driver calls isolated here
        }
    }
}
func (o *txnOwner) Do(fn core.TxnFn) error {
    select { case o.q <- fn: default: o.q <- fn }
    return <-o.done
}
```

For I2C, `exec` simply invokes `fn()` with the concrete `machine.I2C` in scope.

## Stream owner (generic)

```go
type streamOwner struct {
    port   core.UARTPort // or CAN driver wrapper
    txQ    chan []byte
    rxOut  chan<- core.StreamEvent
    devID  string
    maxFrame int
}

func (o *streamOwner) TrySend(p []byte) bool {
    cp := append([]byte(nil), p...)
    select { case o.txQ <- cp: return true; default: return false }
}
func (o *streamOwner) Events() <-chan core.StreamEvent { /* optional: if the owner itself exposes a chan */ }

// TX worker and RX worker as discussed previously.
```

# Board descriptor

Continue to declare ports without leaking class shape:

```go
// internal/platform/boards/descriptor.go
type I2CDesc struct { ID string; SDA, SCL int; Hz uint32 }
type SPIDesc struct { ID string; SCK, MOSI, MISO int }
type UARTDesc struct { ID string; TX, RX int }
type CANDesc struct  { ID string; TX, RX int }

type Descriptor struct {
    Name string
    I2C  []I2CDesc
    SPI  []SPIDesc
    UART []UARTDesc
    CAN  []CANDesc
}
```

Platform provider maps each to either a `TxnOwner` or a `StreamOwner` and registers them in the `BusRegistry`.

# Summary

* Adopt **two bus classes** with a single `BusRegistry`.
* Devices bind to a **class + ID**, not an API shape.
* Implement **TxnOwner** and **StreamOwner** once, per port.
* The HAL loop remains non-blocking and uniform across all capabilities.
* Adding new buses becomes mechanical: platform provider + owner creation; no changes to HAL or devices’ public shape.
