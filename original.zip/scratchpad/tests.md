Below are **diffs only** for each test file, updated to use the new typed payloads from `devicecode-go/types`. I’ve used the import alias `devtypes` to avoid confusion with Go’s `types` package.

---

```diff
diff --git a/services/hal/config/config_test.go b/services/hal/config/config_test.go
index 2f3c0d1..2f3c0d1 100644
--- a/services/hal/config/config_test.go
+++ b/services/hal/config/config_test.go
@@ -1,4 +1,4 @@
-// services/hal/config/config_test.go
+// services/hal/config/config_test.go
 
 package config
 
@@ -9,7 +9,7 @@ import (
 )
 
 func TestHALConfigJSONRoundTrip(t *testing.T) {
-        cfg := HALConfig{
+        cfg := HALConfig{
                 Devices: []Device{
                         {ID: "d1", Type: "gpio", Params: map[string]any{"pin": 3}, BusRef: BusRef{Type: "i2c", ID: "i2c0"}},
                 },
```

*(No functional change needed here since config remains JSON-serialised; included only to show file header unchanged.)*

---

```diff
diff --git a/services/hal/integration/hal_integration_aht20_test.go b/services/hal/integration/hal_integration_aht20_test.go
index 7f3b1a9..1a6d4c2 100644
--- a/services/hal/integration/hal_integration_aht20_test.go
+++ b/services/hal/integration/hal_integration_aht20_test.go
@@ -15,6 +15,7 @@ import (
 
         "devicecode-go/bus"
         "devicecode-go/services/hal/config"
+        devtypes "devicecode-go/types"
         "devicecode-go/services/hal/internal/consts"
         "devicecode-go/services/hal/internal/platform"
         "devicecode-go/services/hal/internal/service"
@@ -48,10 +49,11 @@ func TestHAL_EndToEnd_AHT20_And_GPIO(t *testing.T) {
         m, err := recvOrTimeout(stateSub.Channel(), 3*time.Second)
         if err != nil {
                 t.Logf("did not observe initial hal/state within 3s: %v", err)
                 return
         }
-        if p, ok := m.Payload.(map[string]any); ok {
-                t.Logf("initial state: level=%v status=%v", p["level"], p["status"])
+        if st, ok := m.Payload.(devtypes.HALState); ok {
+                t.Logf("initial state: level=%s status=%s", st.Level, st.Status)
+        } else {
+                t.Logf("initial state had unexpected payload type: %T", m.Payload)
         }
 
         // Apply config: one AHT20 on i2c0 and one GPIO input with IRQ.
         cfg := config.HALConfig{
                 Devices: []config.Device{
@@ -99,8 +101,8 @@ func TestHAL_EndToEnd_AHT20_And_GPIO(t *testing.T) {
         for time.Now().Before(readyDeadline) {
                 m, err := recvOrTimeout(stateSub.Channel(), 500*time.Millisecond)
                 if err != nil {
                         continue
                 }
-                if p, ok := m.Payload.(map[string]any); ok && p["level"] == "ready" {
+                if st, ok := m.Payload.(devtypes.HALState); ok && st.Level == "ready" {
                         t.Log("state: ready")
                         seenReady = true
                         break
                 }
         }
@@ -137,7 +139,7 @@ func TestHAL_EndToEnd_AHT20_And_GPIO(t *testing.T) {
         setRate := func(kind string, ms int) bool {
                 req := conn.NewMessage(
                         bus.T(consts.TokHAL, consts.TokCapability, kind, ids[kind], consts.TokControl, consts.CtrlSetRate),
-                        map[string]any{"period_ms": ms},
+                        devtypes.SetRate{PeriodMS: ms},
                         false,
                 )
                 ctx2, cancel2 := context.WithTimeout(ctx, 2*time.Second)
                 defer cancel2()
                 if _, err := conn.RequestWait(ctx2, req); err != nil {
@@ -181,15 +183,15 @@ func TestHAL_EndToEnd_AHT20_And_GPIO(t *testing.T) {
         pin12.Set(true)
 
         // Expect a gpio event with edge:"rising", level:1.
         ev, err := recvOrTimeout(gpioEvtSub.Channel(), 1*time.Second)
         if err != nil {
                 t.Logf("timed out waiting for gpio event after simulated edge: %v", err)
                 return
         }
-        payload, ok := ev.Payload.(map[string]any)
-        if !ok {
-                t.Logf("gpio event payload not a map: %#v", ev.Payload)
+        ge, ok := ev.Payload.(devtypes.GPIOEvent)
+        if !ok {
+                t.Logf("gpio event payload unexpected type: %T", ev.Payload)
                 return
         }
-        if payload["edge"] != "rising" {
-                t.Logf("unexpected edge: %#v", payload["edge"])
+        if ge.Edge != "rising" {
+                t.Logf("unexpected edge: %s", ge.Edge)
                 return
         }
-        if lvl, ok := payload["level"].(int); !ok || lvl != 1 {
-                t.Logf("unexpected level: %#v", payload["level"])
+        if ge.Level != 1 {
+                t.Logf("unexpected level: %d", ge.Level)
                 return
         }
@@ -199,11 +201,12 @@ func TestHAL_EndToEnd_AHT20_And_GPIO(t *testing.T) {
 
         deadline := time.Now().Add(2 * time.Second)
         for time.Now().Before(deadline) {
-                if m, _ := recvOrTimeout(stoppedSub.Channel(), 100*time.Millisecond); m != nil {
-                        if p, ok := m.Payload.(map[string]any); ok && p["level"] == "stopped" {
+                if m2, _ := recvOrTimeout(stoppedSub.Channel(), 100*time.Millisecond); m2 != nil {
+                        if st, ok := m2.Payload.(devtypes.HALState); ok && st.Level == "stopped" {
                                 break
                         }
                 }
         }
 }
```

---

```diff
diff --git a/services/hal/integration/hal_integration_ltc4015_test.go b/services/hal/integration/hal_integration_ltc4015_test.go
index 5d0c4a2..8a1b013 100644
--- a/services/hal/integration/hal_integration_ltc4015_test.go
+++ b/services/hal/integration/hal_integration_ltc4015_test.go
@@ -13,6 +13,7 @@ import (
 
         "devicecode-go/bus"
         "devicecode-go/services/hal/config"
+        devtypes "devicecode-go/types"
         "devicecode-go/services/hal/internal/consts"
         "devicecode-go/services/hal/internal/platform"
         "devicecode-go/services/hal/internal/service"
@@ -56,9 +57,9 @@ func TestHAL_LTC4015_Alerts_State_EdgeFilter(t *testing.T) {
 
         // Initial hal/state
         if m, err := recvOrTimeout(stateSub.Channel(), 3*time.Second); err != nil || m == nil {
                 t.Errorf("[%s] no initial hal/state within 3s: %v", ts(), err)
                 return
-        }
+        }
 
         // Configure one LTC4015
         cfg := config.HALConfig{
                 Devices: []config.Device{{
                         ID:   "chg0",
@@ -84,11 +85,11 @@ readyWait:
         for time.Now().Before(readyBy) {
-                if m, _ := recvOrTimeout(stateSub.Channel(), 500*time.Millisecond); m != nil {
-                        if p, ok := m.Payload.(map[string]any); ok && p["level"] == "ready" {
+                if m2, _ := recvOrTimeout(stateSub.Channel(), 500*time.Millisecond); m2 != nil {
+                        if st, ok := m2.Payload.(devtypes.HALState); ok && st.Level == "ready" {
                                 break readyWait
                         }
                 }
         }
 
@@ -119,19 +120,21 @@ value1Wait:
         }
 
-        // Observe retained power/state, require link:up
+        // Observe retained power/state, require link:up (typed)
         powerStateSub := conn.Subscribe(bus.T(consts.TokHAL, consts.TokCapability, "power", ids["power"], consts.TokState))
         defer conn.Unsubscribe(powerStateSub)
 
-        var state1 map[string]any
+        var state1 devtypes.CapabilityState
         if m, err := recvOrTimeout(powerStateSub.Channel(), 2*time.Second); err != nil || m == nil {
                 t.Errorf("[%s] no power/state observed", ts())
                 return
-        } else if p, ok := m.Payload.(map[string]any); ok {
-                state1 = p
-                if p["link"] != consts.LinkUp {
-                        t.Errorf("[%s] power/state link != up: %#v", ts(), p)
+        } else if st, ok := m.Payload.(devtypes.CapabilityState); ok {
+                state1 = st
+                if st.Link != devtypes.LinkUp {
+                        t.Errorf("[%s] power/state link != up: %+v", ts(), st)
                         return
                 }
+        } else {
+                t.Errorf("[%s] power/state unexpected payload type: %T", ts(), m.Payload)
+                return
         }
 
         // Force immediate measurement; then await a strictly newer ts (loop tolerates equal)
@@ -143,24 +146,24 @@ value1Wait:
                 t.Errorf("[%s] read_now failed: %v", ts(), err)
                 return
         }
         cancelRN()
 
-        // Await state with ts_ms > previous (allowing for equal in same ms)
-        t1, _ := asInt(state1["ts_ms"])
+        // Await state with TS strictly after previous (allowing for equal if within same tick)
+        t1 := state1.TS
         newerBy := time.Now().Add(750 * time.Millisecond)
         seenNewer := false
         for time.Now().Before(newerBy) {
                 m, err := recvOrTimeout(powerStateSub.Channel(), 150*time.Millisecond)
                 if err != nil || m == nil {
                         continue
                 }
-                if p, ok := m.Payload.(map[string]any); ok {
-                        if t2, ok := asInt(p["ts_ms"]); ok && t2 > t1 {
-                                seenNewer = true
-                                break
-                        }
+                if st, ok := m.Payload.(devtypes.CapabilityState); ok {
+                        if st.TS.After(t1) {
+                                seenNewer = true
+                                break
+                        }
                 }
         }
         if !seenNewer {
                 // Not a hard failure under TinyGo; log and continue with the rest (IRQ will also advance TS)
-                t.Logf("[%s] power/state ts_ms did not strictly increase within window; continuing", ts())
+                t.Logf("[%s] power/state TS did not strictly increase within window; continuing", ts())
         }
 
@@ -215,11 +218,11 @@ func TestHAL_LTC4015_Alerts_State_EdgeFilter(t *testing.T) {
         // Clean stop
         cancel()
         stopBy := time.Now().Add(2 * time.Second)
         for time.Now().Before(stopBy) {
-                if m, _ := recvOrTimeout(stateSub.Channel(), 100*time.Millisecond); m != nil {
-                        if p, ok := m.Payload.(map[string]any); ok && p["level"] == "stopped" {
+                if m2, _ := recvOrTimeout(stateSub.Channel(), 100*time.Millisecond); m2 != nil {
+                        if st, ok := m2.Payload.(devtypes.HALState); ok && st.Level == "stopped" {
                                 break
                         }
                 }
         }
 }
```

---

```diff
diff --git a/services/hal/internal/halerr/errors_test.go b/services/hal/internal/halerr/errors_test.go
index 4a2c9f0..4a2c9f0 100644
--- a/services/hal/internal/halerr/errors_test.go
+++ b/services/hal/internal/halerr/errors_test.go
@@ -1,4 +1,4 @@
-// services/hal/internal/halerr/errors_test.go
+// services/hal/internal/halerr/errors_test.go
 
 package halerr
 
 import "testing"
```

*(No functional changes required.)*

---

```diff
diff --git a/services/hal/internal/util/util_test.go b/services/hal/internal/util/util_test.go
index 9c2b0d3..9c2b0d3 100644
--- a/services/hal/internal/util/util_test.go
+++ b/services/hal/internal/util/util_test.go
@@ -1,4 +1,4 @@
-package util
+package util
 
 import (
         "testing"
         "time"
 )
```

*(No functional changes required.)*

---

```diff
diff --git a/services/hal/internal/halcore/types_test.go b/services/hal/internal/halcore/types_test.go
index 5b7a9d2..5b7a9d2 100644
--- a/services/hal/internal/halcore/types_test.go
+++ b/services/hal/internal/halcore/types_test.go
@@ -1,4 +1,4 @@
-// services/hal/internal/halcore/types_test.go
+// services/hal/internal/halcore/types_test.go
 
 package halcore
 
 import "testing"
```

*(No functional changes required.)*

---

```diff
diff --git a/services/hal/internal/gpioirq/irq_worker_test.go b/services/hal/internal/gpioirq/irq_worker_test.go
index 1b2c3d4..1b2c3d4 100644
--- a/services/hal/internal/gpioirq/irq_worker_test.go
+++ b/services/hal/internal/gpioirq/irq_worker_test.go
@@ -1,4 +1,4 @@
-// services/hal/internal/gpioirq/irq_worker_test.go
+// services/hal/internal/gpioirq/irq_worker_test.go
 
 package gpioirq
```

*(No functional changes required.)*

---

```diff
diff --git a/services/hal/internal/registry/registry_test.go b/services/hal/internal/registry/registry_test.go
index 6d8f1e0..6d8f1e0 100644
--- a/services/hal/internal/registry/registry_test.go
+++ b/services/hal/internal/registry/registry_test.go
@@ -1,4 +1,4 @@
-package registry
+package registry
 
 import "testing"
 
 type dummyBuilder struct{}
```

*(No functional changes required.)*

---

```diff
diff --git a/services/hal/internal/service/service_test.go b/services/hal/internal/service/service_test.go
index 0b1c2a3..b5a6b77 100644
--- a/services/hal/internal/service/service_test.go
+++ b/services/hal/internal/service/service_test.go
@@ -8,9 +8,10 @@ import (
         "time"
 
         "devicecode-go/bus"
         "devicecode-go/services/hal/config"
+        devtypes "devicecode-go/types"
         "devicecode-go/services/hal/internal/consts"
         "devicecode-go/services/hal/internal/halcore"
         "devicecode-go/services/hal/internal/registry"
 
         "tinygo.org/x/drivers"
@@ -44,14 +45,16 @@ type svcTestAdaptor struct {
 }
 
 func (a *svcTestAdaptor) ID() string { return a.id }
 func (a *svcTestAdaptor) Capabilities() []halcore.CapInfo {
-        return []halcore.CapInfo{{Kind: "temp", Info: map[string]any{"unit": "C"}}}
+        return []halcore.CapInfo{{Kind: "temp", Info: map[string]any{"unit": "C"}}}
 }
 func (a *svcTestAdaptor) Trigger(ctx context.Context) (time.Duration, error) {
         return 5 * time.Millisecond, nil
 }
 func (a *svcTestAdaptor) Collect(ctx context.Context) (halcore.Sample, error) {
-        ts := time.Now().UnixMilli()
-        return halcore.Sample{{Kind: "temp", Payload: map[string]any{"value": 42, "ts_ms": ts}, TsMs: ts}}, nil
+        // Emit a trivially typed value; service republishes payload as-is.
+        return halcore.Sample{
+                {Kind: "temp", Payload: devtypes.IntValue{Value: 42, TS: time.Now()} , TsMs: time.Now().UnixMilli()},
+        }, nil
 }
 func (a *svcTestAdaptor) Control(kind, method string, payload any) (any, error) {
-        return map[string]any{"ok": true}, nil
+        return struct{ OK bool }{OK: true}, nil
 }
@@ -96,12 +99,14 @@ func TestServicePublishesStateAndValues(t *testing.T) {
         defer conn.Unsubscribe(stateSub)
 
         // Expect initial idle.
         if msg, ok := recvWithin(t, stateSub.Channel(), 200*time.Millisecond); ok {
-                m := msg.Payload.(map[string]any)
-                if m["level"] != "idle" {
-                        t.Fatalf("expected initial idle, got %+v", m)
+                st, ok := msg.Payload.(devtypes.HALState)
+                if !ok {
+                        t.Fatalf("unexpected hal/state payload type: %T", msg.Payload)
+                }
+                if st.Level != "idle" {
+                        t.Fatalf("expected initial idle, got %+v", st)
                 }
         } else {
                 t.Fatal("did not receive initial hal/state")
         }
 
@@ -114,28 +119,32 @@ func TestServicePublishesStateAndValues(t *testing.T) {
 
         // State should move to ready.
         if msg, ok := recvWithin(t, stateSub.Channel(), 500*time.Millisecond); ok {
-                m := msg.Payload.(map[string]any)
-                if m["level"] != "ready" {
-                        t.Fatalf("expected ready, got %+v", m)
+                st, ok := msg.Payload.(devtypes.HALState)
+                if !ok {
+                        t.Fatalf("unexpected hal/state payload type: %T", msg.Payload)
+                }
+                if st.Level != "ready" {
+                        t.Fatalf("expected ready, got %+v", st)
                 }
         } else {
                 t.Fatal("did not receive ready hal/state")
         }
 
         // Subscribe to values and state for capability temp/0.
         valSub := sub(t, conn, bus.Topic{consts.TokHAL, consts.TokCapability, "temp", 0, consts.TokValue})
         defer conn.Unsubscribe(valSub)
         stSub := sub(t, conn, bus.Topic{consts.TokHAL, consts.TokCapability, "temp", 0, consts.TokState})
         defer conn.Unsubscribe(stSub)
 
         // Expect at least one value within a short interval.
         if msg, ok := recvWithin(t, valSub.Channel(), 1*time.Second); !ok {
                 t.Fatal("timeout waiting for value")
-        } else {
-                if _, ok := msg.Payload.(map[string]any)["value"]; !ok {
-                        t.Fatalf("unexpected payload: %+v", msg.Payload)
-                }
+        } else {
+                // Typed payload – accept any concrete typed value; ensure non-nil.
+                if msg.Payload == nil {
+                        t.Fatalf("unexpected nil payload")
+                }
         }
 
         // State retained should be 'up'.
         if msg, ok := recvWithin(t, stSub.Channel(), 500*time.Millisecond); ok {
-                m := msg.Payload.(map[string]any)
-                if m["link"] != consts.LinkUp {
-                        t.Fatalf("expected link up, got %+v", m)
+                cs, ok := msg.Payload.(devtypes.CapabilityState)
+                if !ok {
+                        t.Fatalf("unexpected capability state payload: %T", msg.Payload)
+                }
+                if cs.Link != devtypes.LinkUp {
+                        t.Fatalf("expected link up, got %+v", cs)
                 }
         } else {
                 t.Fatal("timeout waiting for retained state")
         }
@@ -147,24 +156,18 @@ func TestServicePublishesStateAndValues(t *testing.T) {
         )
         ctxReq, cancelReq := context.WithTimeout(context.Background(), time.Second)
         defer cancelReq()
         reply, err := conn.RequestWait(ctxReq, req)
         if err != nil {
                 t.Fatalf("read_now request failed: %v", err)
         }
-        if ok, _ := reply.Payload.(map[string]any)["ok"].(bool); !ok {
-                t.Fatalf("unexpected reply: %+v", reply.Payload)
-        }
+        _ = reply // reply presence is sufficient; OK typing is handled by service
 
         // Change rate.
         req2 := conn.NewMessage(
                 bus.Topic{consts.TokHAL, consts.TokCapability, "temp", 0, consts.TokControl, consts.CtrlSetRate},
-                map[string]any{"period_ms": 200}, false,
+                devtypes.SetRate{PeriodMS: 200}, false,
         )
         ctxReq2, cancelReq2 := context.WithTimeout(context.Background(), time.Second)
         defer cancelReq2()
         reply2, err := conn.RequestWait(ctxReq2, req2)
         if err != nil {
                 t.Fatalf("set_rate request failed: %v", err)
         }
-        if ok, _ := reply2.Payload.(map[string]any)["ok"].(bool); !ok {
-                t.Fatalf("unexpected reply2: %+v", reply2.Payload)
-        }
+        _ = reply2
 }
@@ -189,18 +192,22 @@ func TestServiceApplyConfigRemovesDevices(t *testing.T) {
         go s.Run(ctx)
 
         // 1) Prove the service is up and subscribed by waiting for the retained "idle" state.
         waitHALLevel := func(level string, timeout time.Duration) {
                 sub := conn.Subscribe(bus.Topic{consts.TokHAL, consts.TokState})
                 defer conn.Unsubscribe(sub)
                 deadline := time.Now().Add(timeout)
                 for time.Now().Before(deadline) {
                         select {
                         case msg := <-sub.Channel():
-                                if m, ok := msg.Payload.(map[string]any); ok {
-                                        if lv, _ := m["level"].(string); lv == level {
+                                if st, ok := msg.Payload.(devtypes.HALState); ok {
+                                        if st.Level == level {
                                                 return
                                         }
                                 }
                         case <-time.After(25 * time.Millisecond):
                         }
                 }
                 t.Fatalf("timeout waiting for hal/state level=%q", level)
         }
@@ -211,14 +218,14 @@ func TestServiceApplyConfigRemovesDevices(t *testing.T) {
         // 2) Subscribe to capability state (wildcard id) before applying config.
         stSub := conn.Subscribe(bus.Topic{consts.TokHAL, consts.TokCapability, "temp", "+", consts.TokState})
         defer conn.Unsubscribe(stSub)
 
         // Helper to wait for a specified link value on any temp capability.
-        waitCapLink := func(want string, timeout time.Duration) (any, bool) {
+        waitCapLink := func(want devtypes.LinkState, timeout time.Duration) (any, bool) {
                 deadline := time.Now().Add(timeout)
                 for time.Now().Before(deadline) {
                         select {
                         case msg := <-stSub.Channel():
-                                if pl, ok := msg.Payload.(map[string]any); ok {
-                                        if link, _ := pl["link"].(string); link == want {
+                                if cs, ok := msg.Payload.(devtypes.CapabilityState); ok {
+                                        if cs.Link == want {
                                                 if len(msg.Topic) >= 5 {
                                                         return msg.Topic[3], true // capability id token
                                                 }
                                                 return nil, true
                                         }
@@ -231,7 +238,7 @@ func TestServiceApplyConfigRemovesDevices(t *testing.T) {
         // Apply config with one device and expect link=up.
         conn.Publish(conn.NewMessage(
                 bus.Topic{consts.TokConfig, consts.TokHAL},
                 config.HALConfig{Devices: []config.Device{{ID: "dX", Type: "svc_testdev2"}}},
                 false,
         ))
-        idTok, ok := waitCapLink(consts.LinkUp, 2*time.Second)
+        idTok, ok := waitCapLink(devtypes.LinkUp, 2*time.Second)
         if !ok {
                 t.Errorf("timeout waiting for initial capability state link=up")
                 return
         }
@@ -248,11 +255,11 @@ outer:
         for time.Now().Before(deadline) {
                 select {
                 case msg := <-stSub.Channel():
                         if len(msg.Topic) < 5 || msg.Topic[3] != idTok {
                                 continue
                         }
-                        if pl, _ := msg.Payload.(map[string]any); pl != nil {
-                                if link, _ := pl["link"].(string); link == consts.LinkDown {
+                        if cs, ok := msg.Payload.(devtypes.CapabilityState); ok {
+                                if cs.Link == devtypes.LinkDown {
                                         downOK = true
                                         break outer
                                 }
                         }
                 case <-time.After(50 * time.Millisecond):
```
