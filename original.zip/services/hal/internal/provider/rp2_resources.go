//go:build rp2040 || rp2350

package provider

import (
	"sync"
	"sync/atomic"
	"time"

	"devicecode-go/errcode"
	"devicecode-go/services/hal/internal/core"
	"devicecode-go/services/hal/internal/provider/boards"
	"devicecode-go/services/hal/internal/provider/setups"
	"devicecode-go/x/mathx"
	"devicecode-go/x/ramp"
	"machine"

	uartx "github.com/jangala-dev/tinygo-uartx/uartx"
	"tinygo.org/x/drivers"
)

// Ensure the provider satisfies the contracts at compile time.
var _ core.ResourceRegistry = (*rp2Registry)(nil)

// -----------------------------------------------------------------------------
// GPIO handle
// -----------------------------------------------------------------------------

type rp2GPIO struct {
	p machine.Pin
	n int
}

func (r *rp2GPIO) Number() int { return r.n }

func (r *rp2GPIO) ConfigureInput(pull core.Pull) error {
	var mode machine.PinMode
	switch pull {
	case core.PullUp:
		mode = machine.PinInputPullup
	case core.PullDown:
		mode = machine.PinInputPulldown
	default:
		mode = machine.PinInput
	}
	r.p.Configure(machine.PinConfig{Mode: mode})
	return nil
}

func (r *rp2GPIO) ConfigureOutput(initial bool) error {
	r.p.Configure(machine.PinConfig{Mode: machine.PinOutput})
	r.p.Set(initial)
	return nil
}

func (r *rp2GPIO) Set(b bool) { r.p.Set(b) }
func (r *rp2GPIO) Get() bool  { return r.p.Get() }
func (r *rp2GPIO) Toggle() {
	if r.p.Get() {
		r.p.Low()
	} else {
		r.p.High()
	}
}

// -----------------------------------------------------------------------------
// PWM internals (RP2040)
// -----------------------------------------------------------------------------

// Local interface to avoid depending on an unexported concrete type in machine.
type pwmCtrl interface {
	Configure(cfg machine.PWMConfig) error
	Top() uint32
	Set(channel uint8, value uint32)
}

// Select controller handle for a given slice number (0..7).
func pwmGroupBySlice(slice uint8) pwmCtrl {
	switch slice {
	case 0:
		return machine.PWM0
	case 1:
		return machine.PWM1
	case 2:
		return machine.PWM2
	case 3:
		return machine.PWM3
	case 4:
		return machine.PWM4
	case 5:
		return machine.PWM5
	case 6:
		return machine.PWM6
	default:
		return machine.PWM7
	}
}

type sliceCfg struct {
	freqHz uint64
	users  int
}

// rp2PWM is the provider's per-pin PWM handle (channel-level).
type rp2PWM struct {
	mu sync.Mutex

	pin   int
	ctrl  pwmCtrl // controller for this pin's slice (PWM0..PWM7)
	chIdx uint8   // channel within controller: 0 => A, 1 => B
	slice int     // 0..7
	ch    rune    // 'A' or 'B'

	enabled bool

	// Logical config (per channel)
	reqTop uint16 // requested logical resolution (0..reqTop)
	freqHz uint64 // requested frequency

	// Hardware info (per slice/controller)
	hwTop uint32 // controller.Top() after Configure

	// Current logical level (0..reqTop)
	level uint16

	// Ramp state
	rampCancel chan struct{}
	rampAlive  bool

	// User accounting (slice-level): true once this handle has contributed
	// to slice users. Prevents double-counting on repeated Configure calls.
	registered bool
}

// caller holds lock
func (p *rp2PWM) setHW(logical uint16) {
	if p.hwTop == 0 || p.reqTop == 0 {
		return
	}
	logical = mathx.Min(logical, p.reqTop)
	// Scale from logical [0..reqTop] to hardware [0..hwTop].
	hw := (uint32(logical) * p.hwTop) / uint32(p.reqTop)
	p.ctrl.Set(p.chIdx, hw)
	p.level = logical
}

func (p *rp2PWM) Configure(freqHz uint64, top uint16) error {
	top = mathx.Max(top, 1)
	freqHz = mathx.Max(freqHz, 1)

	globalPWM.mu.Lock()
	defer globalPWM.mu.Unlock()

	sc := globalPWM.slice[p.slice]
	if sc == nil {
		sc = &sliceCfg{}
		globalPWM.slice[p.slice] = sc
	}

	if sc.users == 0 {
		// First writer configures the controller period for this slice.
		period := PeriodFromHz(freqHz)
		if err := p.ctrl.Configure(machine.PWMConfig{Period: period}); err != nil {
			return err
		}
		sc.freqHz = freqHz
		sc.users = 1
		p.registered = true
	} else {
		// Already in use. If this handle has not yet been counted, enforce
		// frequency compatibility and then count it. If it *has* been counted,
		// allow reconfiguration only if this is the sole user.
		if !p.registered {
			if sc.freqHz != freqHz {
				return errcode.Conflict
			}
			sc.users++
			p.registered = true
		} else if sc.users == 1 && sc.freqHz != freqHz {
			// Sole user may reconfigure the slice frequency.
			period := PeriodFromHz(freqHz)
			if err := p.ctrl.Configure(machine.PWMConfig{Period: period}); err != nil {
				return err
			}
			sc.freqHz = freqHz
		} else if sc.freqHz != freqHz {
			return errcode.Conflict
		}
	}

	// Switch pin to PWM function and cache tops.
	machine.Pin(p.pin).Configure(machine.PinConfig{Mode: machine.PinPWM})

	p.mu.Lock()
	p.freqHz = freqHz
	p.reqTop = top
	p.hwTop = p.ctrl.Top()
	p.mu.Unlock()

	return nil
}

func (p *rp2PWM) Set(level uint16) {
	p.mu.Lock()
	defer p.mu.Unlock()
	// Cancel any active ramp to avoid contention.
	if p.rampAlive {
		close(p.rampCancel)
		p.rampAlive = false
	}
	p.setHW(level)
}

func (p *rp2PWM) Enable(on bool) {
	p.mu.Lock()
	defer p.mu.Unlock()
	// Model enable as "drive current level" vs "drive 0".
	if on {
		p.setHW(p.level)
	} else {
		p.setHW(0)
	}
	p.enabled = on
}

func (p *rp2PWM) Info() (int, rune, int) { return p.slice, p.ch, p.pin }

func (p *rp2PWM) StopRamp() {
	p.mu.Lock()
	if p.rampAlive {
		close(p.rampCancel)
		p.rampAlive = false
	}
	p.mu.Unlock()
}

func (p *rp2PWM) Ramp(to uint16, durationMs uint32, steps uint16, _ core.PWMRampMode) bool {
	// Immediate set when degenerate.
	if steps == 0 || durationMs == 0 {
		p.Set(to)
		return true
	}

	p.mu.Lock()
	if p.rampAlive || p.reqTop == 0 {
		p.mu.Unlock()
		return false
	}
	tgt := mathx.Min(to, p.reqTop)
	start := p.level
	cancel := make(chan struct{})
	p.rampCancel, p.rampAlive = cancel, true
	top := p.reqTop
	p.mu.Unlock()

	go func() {
		defer func() { p.mu.Lock(); p.rampAlive = false; p.mu.Unlock() }()
		timer := time.NewTimer(0)
		// Ensure timer is not left running from construction.
		if !timer.Stop() {
			select {
			case <-timer.C:
			default:
			}
		}
		defer timer.Stop()
		tick := func(d time.Duration) bool {
			timer.Reset(d)
			select {
			case <-cancel:
				if !timer.Stop() {
					select {
					case <-timer.C:
					default:
					}
				}
				return false
			case <-timer.C:
				return true
			}
		}
		ramp.StartLinear(start, tgt, top, durationMs, steps, tick, func(lvl uint16) {
			p.mu.Lock()
			p.setHW(lvl)
			p.mu.Unlock()
		})
	}()
	return true
}

// Global PWM policy: per-slice frequency compatibility.
var globalPWM struct {
	mu    sync.Mutex
	slice map[int]*sliceCfg // slice index -> cfg
}

func init() {
	globalPWM.slice = make(map[int]*sliceCfg)
}

// -----------------------------------------------------------------------------
// PinHandle implementation
// -----------------------------------------------------------------------------

type rp2PinHandle struct {
	n    int
	fn   core.PinFunc
	gpio *rp2GPIO
	pwm  *rp2PWM
}

func (h *rp2PinHandle) Pin() int { return h.n }

func (h *rp2PinHandle) AsGPIO() core.GPIOHandle {
	if h.fn != core.FuncGPIOIn && h.fn != core.FuncGPIOOut {
		panic("pin not claimed for GPIO")
	}
	return h.gpio
}

func (h *rp2PinHandle) AsPWM() core.PWMHandle {
	if h.fn != core.FuncPWM {
		panic("pin not claimed for PWM")
	}
	return h.pwm
}

// -----------------------------------------------------------------------------
// I²C owner (one worker per bus)
// -----------------------------------------------------------------------------

// request posted to the per-bus worker
type i2cReq struct {
	addr uint16
	w, r []byte
	done chan error // buffered(1); worker replies best-effort
}

// per-bus owner that hosts a single worker goroutine
type i2cOwner struct {
	id   core.ResourceID
	hw   *machine.I2C
	reqs chan i2cReq
	quit chan struct{}
}

func newI2COwner(id core.ResourceID, hw *machine.I2C) *i2cOwner {
	o := &i2cOwner{
		id:   id,
		hw:   hw,
		reqs: make(chan i2cReq, 16),
		quit: make(chan struct{}),
	}
	go o.loop()
	return o
}

func (o *i2cOwner) loop() {
	for {
		select {
		case req := <-o.reqs:
			err := o.hw.Tx(req.addr, req.w, req.r)
			// best-effort reply; do not block the worker
			select {
			case req.done <- err:
			default:
			}
		case <-o.quit:
			return
		}
	}
}

func (o *i2cOwner) stop() { close(o.quit) }

// driversI2C adapts the owner to tinygo.org/x/drivers.I2C.
// It posts a request and optionally enforces a per-call timeout.
type driversI2C struct {
	o       *i2cOwner
	timeout time.Duration // 0 => no deadline
}

// Ensure compile-time conformance with drivers.I2C
var _ drivers.I2C = (*driversI2C)(nil)

func (d *driversI2C) Tx(addr uint16, w, r []byte) error {
	req := i2cReq{addr: addr, w: w, r: r, done: make(chan error, 1)}

	if d.timeout <= 0 {
		// Unbounded enqueue (blocks until space is available)
		d.o.reqs <- req
	} else {
		t := time.NewTimer(0)
		// Ensure clean state before use.
		if !t.Stop() {
			select {
			case <-t.C:
			default:
			}
		}
		t.Reset(d.timeout)
		select {
		case d.o.reqs <- req:
			if !t.Stop() {
				select {
				case <-t.C:
				default:
				}
			}
		case <-t.C:
			return errcode.Busy
		}
		// Reuse 't' for completion wait below.
		defer t.Stop()
	}

	// Completion
	if d.timeout <= 0 {
		return <-req.done
	}
	t := time.NewTimer(d.timeout)
	defer t.Stop()
	select {
	case err := <-req.done:
		return err
	case <-t.C:
		return errcode.Timeout
	}
}

// -----------------------------------------------------------------------------
// Resource registry (GPIO + PWM + I2C)
// -----------------------------------------------------------------------------

type rp2Registry struct {
	mu sync.Mutex

	// Unified pin ownership.
	pinOwners map[int]pinOwner // pin -> owner
	gpioMap   map[int]*rp2GPIO // pin -> GPIO view (cached)
	pwmMap    map[int]*rp2PWM  // pin -> PWM view (cached; for reset/release)

	// I2C
	i2cOwners map[core.ResourceID]*i2cOwner

	// UART
	uartPorts  map[core.ResourceID]*rp2SerialPort
	uartOwners map[core.ResourceID]string // <- NEW: bus id -> devID

	// GPIO edge subscriptions
	edge onceIRQ // worker + per-pin tables

}

type pinOwner struct {
	devID string
	fn    core.PinFunc
}

func NewResourceRegistry(plan setups.ResourcePlan) *rp2Registry {
	r := &rp2Registry{
		pinOwners:  make(map[int]pinOwner),
		gpioMap:    make(map[int]*rp2GPIO),
		pwmMap:     make(map[int]*rp2PWM),
		i2cOwners:  make(map[core.ResourceID]*i2cOwner),
		uartPorts:  make(map[core.ResourceID]*rp2SerialPort),
		uartOwners: make(map[core.ResourceID]string),
		edge:       newOnceIRQ(),
	}

	// Instantiate I2C owners from the provided plan (pins and frequency).
	for _, p := range plan.I2C {
		var hw *machine.I2C
		switch p.ID {
		case "i2c0":
			hw = machine.I2C0
		case "i2c1":
			hw = machine.I2C1
		default:
			continue
		}
		// Configure pins & bus frequency.
		sda := machine.Pin(p.SDA)
		scl := machine.Pin(p.SCL)
		sda.Configure(machine.PinConfig{Mode: machine.PinI2C})
		scl.Configure(machine.PinConfig{Mode: machine.PinI2C})
		hw.Configure(machine.I2CConfig{
			SCL:       scl,
			SDA:       sda,
			Frequency: p.Hz,
		})
		r.i2cOwners[core.ResourceID(p.ID)] = newI2COwner(core.ResourceID(p.ID), hw)
	}

	// UART setup
	for _, u := range plan.UART {
		var hw *uartx.UART
		switch u.ID {
		case "uart0":
			hw = uartx.UART0
		case "uart1":
			hw = uartx.UART1
		default:
			continue
		}
		// Configure pins and baud. Defaults inside uartx will apply if zero.
		_ = hw.Configure(uartx.UARTConfig{
			BaudRate: u.Baud,
			TX:       machine.Pin(u.TX),
			RX:       machine.Pin(u.RX),
		})
		r.uartPorts[core.ResourceID(u.ID)] = &rp2SerialPort{u: hw}
	}

	return r
}

func (r *rp2Registry) ClassOf(id core.ResourceID) (core.BusClass, bool) {
	switch string(id) {
	case "i2c0", "i2c1":
		return core.BusTransactional, true
	case "uart0", "uart1":
		return core.BusStream, true
	}
	return 0, false
}

// Transactional buses (I2C)
func (r *rp2Registry) ClaimI2C(devID string, id core.ResourceID) (drivers.I2C, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	o := r.i2cOwners[id]
	if o == nil {
		return nil, errcode.UnknownBus
	}
	return &driversI2C{o: o, timeout: 250 * time.Millisecond}, nil
}

func (r *rp2Registry) ReleaseI2C(devID string, id core.ResourceID) {
	// Owners are long-lived per bus; nothing to do here.
}

// Serial
func (r *rp2Registry) ClaimSerial(devID string, id core.ResourceID) (core.SerialPort, error) {
	r.mu.Lock()
	defer r.mu.Unlock()

	p := r.uartPorts[id]
	if p == nil {
		return nil, errcode.UnknownBus
	}
	if owner, taken := r.uartOwners[id]; taken && owner != "" && owner != devID {
		return nil, errcode.Conflict // serial bus already claimed
	}
	// Record (or reaffirm) ownership.
	r.uartOwners[id] = devID
	return p, nil
}

func (r *rp2Registry) ReleaseSerial(devID string, id core.ResourceID) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if owner, ok := r.uartOwners[id]; ok && owner == devID {
		delete(r.uartOwners, id)
	}
}

// Unified pin claims
func (r *rp2Registry) inBoardRange(n int) bool {
	min, max := boards.SelectedBoard.GPIOMin, boards.SelectedBoard.GPIOMax
	return n >= min && n <= max
}

func (r *rp2Registry) lookupGPIO(n int) *rp2GPIO {
	if g, ok := r.gpioMap[n]; ok {
		return g
	}
	h := &rp2GPIO{p: machine.Pin(n), n: n}
	r.gpioMap[n] = h
	return h
}

func (r *rp2Registry) ClaimPin(devID string, n int, fn core.PinFunc) (core.PinHandle, error) {
	r.mu.Lock()
	defer r.mu.Unlock()

	if !r.inBoardRange(n) {
		return nil, errcode.UnknownPin
	}
	if owner, inUse := r.pinOwners[n]; inUse && owner.devID != "" {
		return nil, errcode.PinInUse
	}

	ph := &rp2PinHandle{n: n, fn: fn}

	switch fn {
	case core.FuncGPIOIn, core.FuncGPIOOut:
		ph.gpio = r.lookupGPIO(n)

	case core.FuncPWM:
		// Determine slice and controller for this pin.
		sliceNum, err := machine.PWMPeripheral(machine.Pin(n))
		if err != nil {
			return nil, errcode.Unsupported
		}
		ctrl := pwmGroupBySlice(sliceNum)
		// Channel within the slice: even pin => A(0), odd pin => B(1).
		chIdx := uint8(n & 1)
		chRune := 'A'
		if chIdx == 1 {
			chRune = 'B'
		}
		ph.pwm = &rp2PWM{
			pin:   n,
			ctrl:  ctrl,
			chIdx: chIdx,
			slice: int(sliceNum),
			ch:    chRune,
		}
		// Cache for later cleanup on release.
		r.pwmMap[n] = ph.pwm

	default:
		return nil, errcode.Unsupported
	}

	r.pinOwners[n] = pinOwner{devID: devID, fn: fn}
	return ph, nil
}

func (r *rp2Registry) ReleasePin(devID string, n int) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if owner, ok := r.pinOwners[n]; ok && owner.devID == devID {
		// Tear down any edge subscription before mode reset.
		r.edge.unsubscribe(n)
		// PWM-specific cleanup (stop ramp, duty=0, slice accounting).
		if owner.fn == core.FuncPWM {
			if p, okp := r.pwmMap[n]; okp && p != nil {
				// Stop any active ramp and drive 0 safely.
				p.StopRamp()
				p.mu.Lock()
				// setHW respects reqTop/hwTop; if never configured, drive via controller.
				if p.hwTop != 0 && p.reqTop != 0 {
					p.setHW(0)
				} else {
					p.ctrl.Set(p.chIdx, 0)
				}
				p.enabled = false
				p.mu.Unlock()

				// Slice user accounting.
				globalPWM.mu.Lock()
				if sc := globalPWM.slice[p.slice]; sc != nil && p.registered {
					if sc.users > 0 {
						sc.users--
					}
					if sc.users == 0 {
						sc.freqHz = 0
					}
					p.registered = false
				}
				globalPWM.mu.Unlock()
			}
		}

		// In all cases, put the pin back to input.
		if g, ok2 := r.gpioMap[n]; ok2 && g != nil {
			g.p.Configure(machine.PinConfig{Mode: machine.PinInput})
		} else {
			machine.Pin(n).Configure(machine.PinConfig{Mode: machine.PinInput})
		}

		// Drop cached PWM view if present.
		delete(r.pwmMap, n)
		delete(r.pinOwners, n)
	}
}

func PeriodFromHz(hz uint64) uint64 {
	if hz == 0 {
		return 0 // or panic
	}
	return uint64(time.Second) / hz
}

// Close stops background workers (e.g. per-bus I2C goroutines).
func (r *rp2Registry) Close() {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, o := range r.i2cOwners {
		if o != nil {
			o.stop()
		}
	}
	r.edge.stop()
}

// ReadOnDieMilliC exposes a single-shot on-die temperature read.
// Only defined on rp2040 builds so the device can feature-detect it.
func (r *rp2Registry) ReadOnDieMilliC() int32 {
	return machine.ReadTemperature() // milli-celsius
}

// rp2SerialPort adapts uartx.UART to serialPortX.
type rp2SerialPort struct{ u *uartx.UART }

func (p *rp2SerialPort) Readable() <-chan struct{} { return p.u.Readable() }
func (p *rp2SerialPort) Writable() <-chan struct{} { return p.u.Writable() }
func (p *rp2SerialPort) TryRead(b []byte) int      { return p.u.TryRead(b) }
func (p *rp2SerialPort) TryWrite(b []byte) int     { return p.u.TryWrite(b) }
func (p *rp2SerialPort) Flush() error              { return p.u.Flush() }

func (p *rp2SerialPort) SetBaudRate(br uint32) error { p.u.SetBaudRate(br); return nil }

// Parity strings: "none","even","odd"
func (p *rp2SerialPort) SetFormat(databits, stopbits uint8, parity string) error {
	var par uartx.UARTParity
	switch parity {
	case "even":
		par = uartx.ParityEven
	case "odd":
		par = uartx.ParityOdd
	default:
		par = uartx.ParityNone
	}
	return p.u.SetFormat(databits, stopbits, par)
}

// -----------------------------------------------------------------------------
// GPIO IRQ worker: best-effort edge delivery with debounce and selection
// -----------------------------------------------------------------------------

// onceIRQ encapsulates a single worker that services all pins.
type onceIRQ struct {
	mu      sync.Mutex
	subs    map[int]*edgeSub // pin -> subscription
	wake    chan struct{}    // size 1; ISRs perform non-blocking send
	running bool
	quit    chan struct{}
	done    chan struct{}

	// Pending bitset (GPIO 0..29 on RP2040 -> fits in 64 bits).
	pending atomic.Uint64
}

func newOnceIRQ() onceIRQ {
	return onceIRQ{
		subs: make(map[int]*edgeSub),
		wake: make(chan struct{}, 1),
	}
}

type edgeSub struct {
	devID    string
	pin      int
	edges    core.GPIOEdge
	debounce time.Duration
	ch       chan core.GPIOEdgeEvent
	closed   bool

	// qualification state
	lastTS  int64  // ns
	lastLvl uint32 // 0/1
}

type gpioEdgeStream struct {
	s      *edgeSub
	parent *onceIRQ
}

func (g *gpioEdgeStream) Events() <-chan core.GPIOEdgeEvent { return g.s.ch }
func (g *gpioEdgeStream) Close()                            { g.parent.unsubscribe(g.s.pin) }
func (g *gpioEdgeStream) SetDebounce(d time.Duration) bool {
	g.parent.mu.Lock()
	g.s.debounce = d
	g.parent.mu.Unlock()
	return true
}
func (g *gpioEdgeStream) SetEdges(sel core.GPIOEdge) bool {
	flags := mapEdges(sel)
	if !installISRForPin(g.parent, g.s.pin, flags) {
		return false
	}
	g.parent.mu.Lock()
	g.s.edges = sel
	g.parent.mu.Unlock()
	return true
}

// Subscribe from registry.
func (r *rp2Registry) SubscribeGPIOEdges(devID string, pin int, sel core.GPIOEdge, debounce time.Duration, buf int) (core.GPIOEdgeStream, error) {
	r.mu.Lock()
	defer r.mu.Unlock()

	owner, ok := r.pinOwners[pin]
	if !ok {
		return nil, errcode.UnknownPin
	}
	if owner.devID != devID || owner.fn != core.FuncGPIOIn {
		return nil, errcode.Conflict
	}
	if buf <= 0 {
		buf = 8
	}
	s := &edgeSub{
		devID:    devID,
		pin:      pin,
		edges:    sel,
		debounce: debounce,
		ch:       make(chan core.GPIOEdgeEvent, buf),
		lastLvl:  b2u(machine.Pin(pin).Get()),
		lastTS:   time.Now().UnixNano(),
	}

	// Register subscription before enabling interrupts so an immediate IRQ
	// has a destination with initial state already seeded.
	r.edge.subscribe(s)

	// Now attach ISR. If this fails, roll back the subscription.
	flags := mapEdges(sel)
	if flags != 0 && !installISRForPin(&r.edge, pin, flags) {
		r.edge.unsubscribe(pin)
		return nil, errcode.Unsupported
	}
	return &gpioEdgeStream{s: s, parent: &r.edge}, nil
}

func (r *rp2Registry) UnsubscribeGPIOEdges(devID string, pin int) {
	r.mu.Lock()
	if owner, ok := r.pinOwners[pin]; ok && owner.devID == devID {
		r.edge.unsubscribe(pin)
	}
	r.mu.Unlock()
}

// Internal: add/remove subscription and manage worker lifecycle.
func (w *onceIRQ) subscribe(s *edgeSub) {
	w.mu.Lock()
	w.subs[s.pin] = s
	if !w.running {
		w.quit = make(chan struct{})
		w.done = make(chan struct{}) // NEW: fresh done chan per start
		go w.loop()
		w.running = true
	}
	w.mu.Unlock()
}

func (w *onceIRQ) unsubscribe(pin int) {
	w.mu.Lock()
	if s := w.subs[pin]; s != nil {
		s.closed = true
		if s.ch != nil {
			close(s.ch)
			s.ch = nil
		}
		delete(w.subs, pin)
	}
	disableISRForPin(pin)
	if w.running && len(w.subs) == 0 {
		close(w.quit)
		w.running = false
	}
	w.mu.Unlock()
}

func (w *onceIRQ) stop() {
	// Signal quit and wait for worker to finish to avoid races.
	w.mu.Lock()
	if w.running {
		close(w.quit)
	}
	done := w.done
	w.mu.Unlock()

	if done != nil {
		<-done // wait for worker exit (NEW)
	}
	// With worker stopped, it is now safe to tear down remaining state.
	w.mu.Lock()
	for pin := range w.subs {
		disableISRForPin(pin)
	}
	for _, s := range w.subs {
		if !s.closed {
			s.closed = true
		}
		if s.ch != nil {
			close(s.ch)
			s.ch = nil
		}
	}
	w.subs = make(map[int]*edgeSub)
	w.running = false
	w.mu.Unlock()
}

// Worker: drain wake-ups, snapshot pending pins, qualify, deliver best-effort.
func (w *onceIRQ) loop() {
	defer func() {
		// Signal that the worker has exited.
		w.mu.Lock()
		if w.done != nil {
			close(w.done)
		}
		w.mu.Unlock()
	}()
	for {
		select {
		case <-w.wake:
			bits := w.pending.Swap(0)
			if bits == 0 {
				continue
			}
			now := time.Now().UnixNano()
			for pin := 0; pin <= 29; pin++ {
				if (bits>>uint(pin))&1 == 0 {
					continue
				}
				// Snapshot subscription state under lock.
				w.mu.Lock()
				s := w.subs[pin]
				if s == nil {
					w.mu.Unlock()
					continue
				}
				if s.closed {
					// One-time channel close on observing closed (worker owns closing).
					if s.ch != nil {
						close(s.ch)
						s.ch = nil
					}
					w.mu.Unlock()
					continue
				}
				prev := s.lastLvl
				lastTS := s.lastTS
				debounce := s.debounce
				edges := s.edges
				ch := s.ch // send to this after unlock
				w.mu.Unlock()
				lvl := machine.Pin(pin).Get()

				curr := b2u(lvl)

				// Debounce
				if debounce > 0 && (now-lastTS) < int64(debounce) {
					w.mu.Lock()
					if t := w.subs[pin]; t != nil {
						t.lastLvl, t.lastTS = curr, now
					}
					w.mu.Unlock()
					continue
				}
				// Edge qualification
				rise := prev == 0 && curr == 1
				fall := prev == 1 && curr == 0
				if (rise && (edges&core.EdgeRising) == 0) || (fall && (edges&core.EdgeFalling) == 0) {
					w.mu.Lock()
					if t := w.subs[pin]; t != nil {
						t.lastLvl, t.lastTS = curr, now
					}
					w.mu.Unlock()
					continue
				}
				ev := core.GPIOEdgeEvent{Pin: pin, Level: lvl, TS: now}
				// Commit new state and deliver best-effort.
				w.mu.Lock()
				if t := w.subs[pin]; t != nil {
					t.lastLvl, t.lastTS = curr, now
				}
				// re-check closed before sending
				if t := w.subs[pin]; t != nil && !t.closed && ch != nil {
					w.mu.Unlock()
					select {
					case ch <- ev:
					default:
						// drop oldest then retry
						select {
						case <-ch:
						default:
						}
						select {
						case ch <- ev:
						default:
						}
					}
				} else {
					// closed or gone
					if t != nil && t.closed && t.ch != nil {
						close(t.ch)
						t.ch = nil
					}
					w.mu.Unlock()
				}
			}
		case <-w.quit:
			return
		}
	}
}

// Helpers
func b2u(b bool) uint32 {
	if b {
		return 1
	}
	return 0
}

func (w *onceIRQ) markPending(pin int) {
	mask := uint64(1) << uint(pin)
	for {
		old := w.pending.Load()
		if w.pending.CompareAndSwap(old, old|mask) {
			return
		}
	}
}

func mapEdges(sel core.GPIOEdge) machine.PinChange {
	switch sel {
	case core.EdgeRising:
		return machine.PinRising
	case core.EdgeFalling:
		return machine.PinFalling
	case core.EdgeBoth:
		return machine.PinRising | machine.PinFalling
	default:
		return 0
	}
}

// ISR plumbing: single shared handler; owner set per-registry.
var (
	isrOwnerMu sync.Mutex
	isrOwner   *onceIRQ
)

// Shared ISR callback (no closures).
func gpioISR(p machine.Pin) {
	pin := int(p)
	isrOwnerMu.Lock()
	owner := isrOwner
	isrOwnerMu.Unlock()
	if owner != nil {
		owner.markPending(pin)
		select {
		case owner.wake <- struct{}{}:
		default:
		}
	}
}

func installISRForPin(owner *onceIRQ, pin int, flags machine.PinChange) bool {
	isrOwnerMu.Lock()
	isrOwner = owner
	isrOwnerMu.Unlock()
	if flags == 0 {
		_ = machine.Pin(pin).SetInterrupt(0, nil)
		return true
	}
	_ = machine.Pin(pin).SetInterrupt(flags, gpioISR)
	return true
}

func disableISRForPin(pin int) {
	_ = machine.Pin(pin).SetInterrupt(0, nil)
}
